import fs from 'fs';

export function obterTodosDados() {
  const arq = fs.readFileSync(process.cwd() + '/data/bancoDeDadosFT.json', 'utf8');
  return JSON.parse(arq);

}

// export function obterTodosNomes() {
//   const nomes = obterTodosDados();
//   return nomes.map((n) => n.nome);

// }

// export function obterNome(nome) {
//   const nomes = obterTodosNomes();
//   return nomes.find((n) => n.nome == nome);

// }

export function criarDados(dado) {
  const dados = obterTodosDados();
  dados.push(dado);

  try {
    const arq = fs.writeFileSync(process.cwd() + '/data/bancoDeDados.json', JSON.stringify(dados), 'utf8');
    return true;

  } catch (e) {
    return false;

  }

}

// export function excluirTopico(titulo: string): boolean {

//   const topicos = obterTodosTopicos().filter((t) => t.titulo !== titulo);

//   try {
//     const arq = fs.writeFileSync(
//       process.cwd() + '/data/topicos.json',
//       JSON.stringify(topicos),
//       'utf8');
//     return true;
//   }
//   catch (e) {
//     return false;
//   }
// }
