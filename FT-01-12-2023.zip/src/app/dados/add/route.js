import { criarDados } from "@/data/bancoDeDadosFT";

export async function POST(request) {

  const res = await request.json();
  const nome = res.nome;
  const email = res.email;
  const senha = res.senha;

  if (nome && email && senha) {
    return Response.json({ resposta: criarDados({ nome: nome, email: email, senha: senha }) });

  } else {
    return Response.json({ resposta: false });

  }

}
