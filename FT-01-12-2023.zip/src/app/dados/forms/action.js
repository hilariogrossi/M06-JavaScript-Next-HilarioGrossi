'use server'

import { revalidatePath } from "next/cache";
import { z } from "zod";

export async function novoTopico(prevState, formData) {

  const schema = z.object({
    nome: z.string().min(4),
    email: z.string().min(10),
    senha: z.string().min(8),

  });

  const parse = schema.safeParse({
    nome: formData.get('nome'),
    email: formData.get('email'),
    senha: formData.get('senha'),

  });

  if (!parse.success) {
    alert({ mensagem: 'Falha ao criar o usuário.' });

  }

  const dados = parse.data;

  const res = await enviar(
    'http://localhost:3000/dados/add',
    { nome: dados.nome, email: dados.email, senha: dados.senha }

  );

  if (res.resposta) {
    revalidatePath('/dados');
    alert({ mensagem: 'Novo usuário criado:' + dados.nome });

  } else {
    alert({ mensagem: 'Não foi possível criar o usuário:' + dados.nome });

  }

}

async function enviar(url, conteudo) {
  const res = await fetch(url, { method: 'POST', body: JSON.stringify(conteudo) });

  if (!res.ok) {
    throw new Error('Falha em criar o usuário.');

  }

  return res.json();

}