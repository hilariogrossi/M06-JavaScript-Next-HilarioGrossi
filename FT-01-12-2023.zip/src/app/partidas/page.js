import React from 'react';
// import Image from 'next/image';
// import styles from './page.module.css';
import Header from '../Header';

export default function Partidas() {
  return (
    <>
        <Header />

        <div>
            Página de Partidas

        </div>
    
    </>

  );

}
