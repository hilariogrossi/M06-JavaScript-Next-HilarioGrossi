import React from 'react';
import Image from 'next/image';
import styles from './page.module.css';

export default function Header() {
  return (
      <div>
          <nav id={styles.cabecalho}>

            <a href="/" className="logo">
                  <Image src="/images/boladefogo.png" width={55} height={55} />
              
            </a>
            
            <a href="/" className='tag-a'>
              <p className="frase">FutebolTotal</p>

            </a>

            <span className={styles.span_1}>
                <a href="/partidas" className='tag-a' target='_blank'>Partidas</a>

            </span>

            <span className={styles.span_1}>
                <a href="/times" className='tag-a' target='_blank'>Times</a>

            </span>

            <span className={styles.span_1}>
                <a href="/competicoes" className='tag-a' target='_blank'>Competições</a>

            </span>

            <span className={styles.span_1}>
                <a href="/procurar" className='tag-a' target='_blank'>
                  <Image src="/images/lupa.png" width={30} height={30} />
                  
                </a>

            </span>

            <span className={styles.span_1}>
              <Image src="/images/pipeline.png" width={30} height={30} />

            </span>

            <span className={styles.span_1}>
              <a href="/configuracoes" className='tag-a' target='_blank'>
                <Image src="/images/engrenagem.svg" width={50} height={50} />

              </a>

            </span>

            <span className={styles.span_1}>
                <a href="/loginpage" className="btn cadastro" target='_blank'>Cadastre-se</a>

            </span>

            <span className={styles.span_1}>
                <a href="/loginpage" className="btn entrar" target='_blank'>Entrar</a>

            </span>

          </nav>

      </div>

    
  );

}
