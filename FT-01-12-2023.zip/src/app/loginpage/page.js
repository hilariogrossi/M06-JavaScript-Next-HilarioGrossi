import React from 'react';
import Header from '../Header';
import CadastroUsuario from './CadastroUsuario';

export default function LoginPage() {
  return (
    <>
        <Header />

        <div>
            <CadastroUsuario />

        </div>
    
    </>

  );

}
