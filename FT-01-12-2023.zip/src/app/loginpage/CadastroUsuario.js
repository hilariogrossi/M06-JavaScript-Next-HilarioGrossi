'use client'

import React, { useState } from 'react';
import styles from './page.module.css';

function CadastroUsuario() {

    const [ nome, setNome ] = useState('');
    const [ email, setEmail ] = useState('');
    const [ senha, setSenha ] = useState('');
    const [dadosCadastrados, setDadosCadastrados] = useState(null);

    const isValidEmail = (email) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);

    };

    const lidarComCadastro = (event) => {
        event.preventDefault();

        if (!isValidEmail(email)) {
            alert('E-mail Inválido! Por favor, insira um e-mail válido.')
            return;
    
        }

        // console.log('Dados a serem armazenados: ', { nome, email, senha });

        setDadosCadastrados({ nome, email, senha });

        setNome('');
        setEmail('');
        setSenha('');

    }

    return (

        <>
            <h1 className={styles.h1}>Página de Cadastro</h1>
            
            <div className={styles.div}>
                
                <form className={styles.form_usuario} onSubmit={lidarComCadastro}>
                    <p className={styles.paragrafo}>Nome: </p><input className={styles.inputs_usuario} type='text' id='nome' value={nome} autoFocus onChange={(e) => setNome(e.target.value)} /> <br />
                    <p className={styles.paragrafo}>E-mail: </p><input className={styles.inputs_usuario} type='text' id='email' value={email} onChange={(e) => setEmail(e.target.value)} /> <br />
                    <p className={styles.paragrafo}>Senha: </p><input className={styles.inputs_usuario} type='text' id='senha' value={senha} onChange={(e) => setSenha(e.target.value)} /> <br />

                    <button className={styles.button_usuario} type='submit'>Cadastrar</button>

                </form>

                {dadosCadastrados && (
                    <div id={styles.dados_cadastrados}>
                        <h2>Dados Cadastrados:</h2>
                        <p>Nome: {dadosCadastrados.nome}</p>
                        <p>E-mail: {dadosCadastrados.email}</p>
                        <p>Senha: {dadosCadastrados.senha}</p>

                    </div>

                )}

            </div>
        
        </>

    );

}

export default CadastroUsuario;
