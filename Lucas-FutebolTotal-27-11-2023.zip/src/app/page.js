import Image from 'next/image';
import styles from './page.module.css';
import boladefogo from '../app/images/boladefogo.png';
import pipeline from './images/pipeline.png';
import lupa from './images/lupa.png';

export default function Home() {
  return (
    <div>
        <nav id={styles.cabecalho}>
            <a href="/" id='a' className="logo">
                <img src={boladefogo} alt="bola" />
                <p className="frase">FutebolTotal</p>
            </a>

            <span className={styles.span_1}>
                <a href="#">Partidas</a>

            </span>

            <span className={styles.span_1}>
                <a href="#">Times</a>

            </span>

            <span className={styles.span_1}>
                <a href="#">Competições</a>

            </span>

            <span className={styles.span_1}>
                <a href="#"><img id="lupa" src={lupa} alt="Lupa" /></a>

            </span>

            <span className={styles.span_1}>
                <img id="pipeline" src={pipeline} alt="Pipe Line" />

            </span>

            <span className={styles.span_1}>
                <a href="#"><div className="fas fa-cog" id="menu-btn"></div></a>

            </span>

            <span className={styles.span_1}>
                <a href="./loginPage.html" className="btn cadastro" target='_blank'>Cadastre-se</a>

            </span>

            <span className={styles.span_1}>
                <a href="./loginPage.html" className="btn entrar" target='_blank'>Entrar</a>

            </span>

        </nav>

    </div>
    
  );

}
