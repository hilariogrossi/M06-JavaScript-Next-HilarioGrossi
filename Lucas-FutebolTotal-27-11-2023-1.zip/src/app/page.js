import React from 'react';
import Image from 'next/image';
import styles from './page.module.css';

export default function Home() {
  return (
    <div>
        <nav id={styles.cabecalho}>
            <a href="/" id='a' className="logo">
              <Image src="/images/boladefogo.png" width={55} height={55} />
              <p className="frase">FutebolTotal</p>
            </a>

            <span className={styles.span_1}>
                <a href="#">Partidas</a>

            </span>

            <span className={styles.span_1}>
                <a href="#">Times</a>

            </span>

            <span className={styles.span_1}>
                <a href="#">Competições</a>

            </span>

            <span className={styles.span_1}>
                <a href="#">
                  <Image src="/images/lupa.png" width={30} height={30} />
                  
                </a>

            </span>

            <span className={styles.span_1}>
              <Image src="/images/pipeline.png" width={30} height={30} />

            </span>

            <span className={styles.span_1}>
                <a href="#"><div className="fas fa-cog" id="menu-btn"></div></a>

            </span>

            <span className={styles.span_1}>
                <a href="/loginpage" className="btn cadastro" target='_blank'>Cadastre-se</a>

            </span>

            <span className={styles.span_1}>
                <a href="/loginpage" className="btn entrar" target='_blank'>Entrar</a>

            </span>

        </nav>

    </div>
    
  );

}
