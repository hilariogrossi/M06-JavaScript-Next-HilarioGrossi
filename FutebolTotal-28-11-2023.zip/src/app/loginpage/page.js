import React from 'react';
import Image from 'next/image';
// import styles from './page.module.css';
import Header from '../Header';

export default function LoginPage() {
  return (
    <>
        <Header />

        <div>
            Pagina de Login

        </div>
    
    </>

  );

}
