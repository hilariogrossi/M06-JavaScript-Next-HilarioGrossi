import React from 'react';
import styles from './page.module.css';
import Header from './Header';

export default function Home() {
  return (
    <>
      <Header />

      <div className={styles.noticias}>
            <div className={styles.noticias_row}>
              <div className={styles.noticia_1}>
                <iframe src="https://g1.globo.com/"></iframe>
        
              </div>

              <div className={styles.noticia_2}>
                <iframe src="https://www.ogol.com.br/"></iframe>

              </div>

            </div>

            <div className={styles.noticias_row}>
              <div className={styles.noticia_3}>
                <iframe src="https://ge.globo.com/"></iframe>

              </div>

              <div className={styles.noticia_4}>
                <iframe src="https://www.cbf.com.br/"></iframe>

              </div>

            </div>

        </div>

    </>
    
  );

}
